package com.projeto.service;

import javax.persistence.EntityManager;

import java.sql.Date;
import java.util.List;

import com.projeto.entities.EventoEntity;
import com.projeto.repository.EventoRepository;
import com.projeto.repository.CustomizerFactory;

public class EventoService {

    //  metodo para salvar um novo evento no banco de dados
    public void salvarEvento(EventoEntity evento) {
        EntityManager em = CustomizerFactory.getEntityManager();
        EventoRepository repository = new EventoRepository(em);
        repository.salvar(evento);
        em.close();
    }

    //  metodo para buscas todos os eventos
    public List<EventoEntity> buscarTodos() {
        EntityManager em = CustomizerFactory.getEntityManager();
        EventoRepository repository = new EventoRepository(em);
        List<EventoEntity> lista = repository.buscarTodos(); //metodo de select apra buscar todos os eventos
        em.close();
        return lista;
    }

    //  metodo para buscar evento por ID
    public EventoEntity buscarPorId(Long id) {
        EntityManager em = CustomizerFactory.getEntityManager();
        EventoRepository repository = new EventoRepository(em);
        EventoEntity evento = repository.buscarPorId(id);
        em.close();
        return evento;
    }

    // metodo para atualizar evento
    public void atualizarEvento(EventoEntity evento) {
        EntityManager em = CustomizerFactory.getEntityManager();
        EventoRepository repository = new EventoRepository(em);
        repository.atualizar(evento);
        em.close();
    }

    // metodo para remove evento por ID
    public boolean removerEvento(Long id) {
        EntityManager em = CustomizerFactory.getEntityManager();
        EventoRepository repository = new EventoRepository(em);
        EventoEntity evento = repository.buscarPorId(id);
        if (evento != null) {
            repository.remover(evento);
            return true;
        }
        em.close();
        return false;
    }
    //metodo para buscar por intervalo de datas
    public List<EventoEntity> buscarPorIntervaloDeDatas(Date dataInicio, Date dataFim) {
        EntityManager em = CustomizerFactory.getEntityManager();
        EventoRepository repository = new EventoRepository(em);
        List<EventoEntity> eventos = repository.buscarPorIntervaloDeDatas(dataInicio, dataFim);
        em.close();
        return eventos;
    }
}
