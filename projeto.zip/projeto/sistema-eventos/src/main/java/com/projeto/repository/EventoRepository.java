package com.projeto.repository;

import com.projeto.entities.EventoEntity;
import com.projeto.entities.PalestranteEntity;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import java.sql.Date;
import java.util.List;

public class EventoRepository {

    private EntityManager em;

    public EventoRepository(EntityManager em) {
        this.em = em;
    }

    //  Salvar evento
    public void salvar(EventoEntity evento) {
        em.getTransaction().begin(); //inicia uma transacao 
        em.persist(evento); // salva essa transacao
        em.getTransaction().commit(); //confirma essa transacao
    }

    //  Buscar todos os eventos com o select 
    public List<EventoEntity> buscarTodos() {
        TypedQuery<EventoEntity> query = em.createQuery("SELECT e FROM EventoEntity e", EventoEntity.class);
        return query.getResultList();
    }

    //  Buscar evento por ID
    public EventoEntity buscarPorId(Long id) {
        return em.find(EventoEntity.class, id);
    }

    // Atualizar evento
    public void atualizar(EventoEntity evento) {
        em.getTransaction().begin(); // faz a transacao
        em.merge(evento); //
        em.getTransaction().commit(); //faz o commit(confirma a transacao)
    }

    // Remover evento
    public void remover(EventoEntity evento) {
        em.getTransaction().begin();
        if (!em.contains(evento)) {
            evento = em.merge(evento);
        }
        em.remove(evento);
        em.getTransaction().commit();
    }
    //busca os eventos pelo palestrante
    public List<EventoEntity> buscarPorPalestrante(PalestranteEntity palestrante) {
        TypedQuery<EventoEntity> query = em.createQuery(
            "SELECT e FROM EventoEntity e WHERE e.palestrante = :palestrante", EventoEntity.class
        );
        query.setParameter("palestrante", palestrante);
        return query.getResultList();
    }
    //busca o evento por data
    public List<EventoEntity> buscarPorIntervaloDeDatas(Date dataInicio, Date dataFim) {
        String jpql = "SELECT e FROM EventoEntity e WHERE e.data_evento BETWEEN :dataInicio AND :dataFim";
        TypedQuery<EventoEntity> query = em.createQuery(jpql, EventoEntity.class);
        query.setParameter("dataInicio", dataInicio);
        query.setParameter("dataFim", dataFim);
        return query.getResultList();
    }
}